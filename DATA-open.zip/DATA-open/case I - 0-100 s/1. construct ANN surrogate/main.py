import numpy as np
import torch
from neural_network import *

#-------------------GPU set----------------
if torch.cuda.is_available():
    DEVICE = torch.device('cuda')
    torch.backends.cudnn.benchmark = True
else:
    DEVICE = torch.device('cpu')


#----------------数据读取----------------------
filename = r'caseI.dat' # txt文件和当前脚本在同一目录下，所以不用写具体路径
pos = []
un=np.ones([500,500])
j=0
unm=0
with open(filename, 'r') as file_to_read:
    while True:
        lines = file_to_read.readline() # 整行读取数据
        for line in lines.split():
            pos.append(line)
        for i in range(len(pos)):
            un[j,i]=float(pos[i])/50
        pos=[]
        j+=1
        unm+=1
        if not lines:
            break

x=np.arange(0,500,1)
t=np.arange(0,100,0.2)
x = x*2e-2
t = t*1.22625e-1 #for case I
#t = t*3.310149e-3 #for case II
np.savetxt("H_n_true_quan.txt",un,delimiter=' ')
# fig = plt.figure()
# #定义画布为1*1个划分，并在第1个位置上进行作图
# ax = fig.add_subplot(111)
# im = ax.imshow(un_stable, cmap=plt.cm.rainbow)
# #增加右侧的颜色刻度条
# cbar=plt.colorbar(im)
# plt.show()
#------------------数据处理----------------------
dx = x[1] - x[0]
dt = t[1] - t[0]
nx = x.shape[0]
nt = t.shape[0]
#x和T
total=nx*nt
choose=200000
choose_validate=25000
noise_level=0
un_raw=torch.from_numpy(un.T.astype(np.float32))
data=torch.zeros(2)
h_data=torch.zeros([total,1])
database=torch.zeros([total,2])
x_num=nx
t_num=nt
num=0

for j in range(x_num):
    for i in range(t_num):
        un_raw[j,i]=un_raw[j,i]#*(1+0.01*np.random.uniform(-1,1))


#save model dir
try:
    os.makedirs('model_save_entire/draft-%d-%d-softplus'%(choose,noise_level))
except OSError:
    pass

#produce random dataset
h_data_choose,h_data_validate,database_choose,database_validate=random_data(total,choose,choose_validate,x,t,un_raw,x_num,t_num)


#neural network
iter_num=3000000
num=0
torch.manual_seed(525)

Net=ANN(in_neuron=2,hidden_neuron=50,out_neuron=1).to(DEVICE)
database_choose = Variable(database_choose.cuda(),requires_grad=True)
database_validate = Variable(database_validate.cuda(),requires_grad=True)
h_data_choose=Variable(h_data_choose.cuda())

#optimizer=torch.optim.LBFGS(Net.parameters(),max_iter=10000,lr=0.02)# 传入网络参数和学习率
optimizer=torch.optim.Adam([
    {'params': Net.parameters()},
    #{'params': theta},
])

with open('model_save_entire/draft-%d-%d-softplus/'%(choose,noise_level)+'data.txt', 'w') as f:  # 设置文件对象
    for t in range(iter_num):
        optimizer.zero_grad()
        prediction = Net(database_choose)
        prediction_validate = Net(database_validate).cpu().data.numpy()
        a = PINNLossFunc(h_data_choose)
        loss = a(prediction) / choose
        loss_validate = np.sum((h_data_validate.data.numpy() - prediction_validate) ** 2) / choose_validate
        loss.backward()
        optimizer.step()
        if t % 1000 == 0:
            print("iter_num: %d      loss: %.8f    loss_validate: %.8f" % (t, loss, loss_validate))
            f.write("iter_num: %d      loss: %.8f    loss_validate: %.8f \r\n" % (t, loss, loss_validate))
            if int(t / 100) == 1000:
                # sign=stop(loss_validate_record)
                # if sign==0:
                #     break
                break
            if t>1000:
                torch.save(Net.state_dict(), 'model_save_entire/draft-%d-%d-softplus/'%(choose,noise_level)+"draft-10000-%d.pkl"%(t))

    #torch.save(Net.state_dict(), "CI-10000-5%.pkl")