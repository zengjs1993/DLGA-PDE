clear all;
global Lx Nx Dx Ly Ny Dy lap alphaf
global Cin Clim Uin Ux Uy dt t_end
global T Visc Rhos Rhol

close all;

%Grid
Lx = 500; Nx = 500; Dx = Lx/Nx;
Ly = 50; Ny = 50; Dy = Ly/Ny;
lap = 3;

Visc = 1e-6;
Rhos = 2.5e3; Rhol = 1e3;
ratio = 1;%39.54;%
%Initial
Cin = 0.2; Uin = 0.;
Ux = 0.; Uy = -0.;
Clim = 0.65/0.2*Cin;%;
width = 5e-3;
%Memory
X = (-lap+0.5)*Dx:Dx:Lx+(lap-0.5)*Dx;
Y = (-lap+0.5)*Dy:Dy:Ly+(lap-0.5)*Dy;
T.C = zeros(Nx+2*lap,Ny+2*lap);
T.C(1:Nx/2+lap,:) = Cin;

T.Fx = zeros(Nx+1,Ny);
T.Fy = zeros(Nx,Ny+1);
T.Ux = ones(Nx+1,Ny)*Ux;
T.Uy = ones(Nx,Ny+1)*Uy;

alphaf = rand(Nx,Ny)*0.5+0.5;
alphaf = ones(Nx,Ny)*0.5+0.5;
%alphaf(1:Nx/2,:) = 1;
%Time control
t_ref = ratio*Visc*Ly/(9.81*Cin*(Rhos-Rhol)/Rhol*width^2/12);
dt = 0.1;%t_ref/50/1;%
Nt = 1000;%500;
t_end = dt*Nt;
% dt = 0.2;
% t_end = 100;

for i=1:Nt
    RungeKutta();
    
    % sharpen interface
    T.C = conservative_level_set(T.C,alphaf);
    
    C{i} = T.C(lap+1:Nx+lap,lap+1:Ny+lap);
    [P{i} UUx{i} UUy{i}] = poisson(C{i},width);
    T.Ux = UUx{i};
    T.Uy = UUy{i}+Uy;
    
    startCurrent = 1;
    endCurrent = Nx;
    
    for j=1:Nx
        idx = find(C{i}(j,:)<Cin*0.5,1);
        if(isempty(idx))
            height(j,i) = Ly-0.5*Dy;%Ly-(Cin-C{i}(j,Ny))/Cin*Dy;%
        else if (idx == 1)
                height(j,i) = 0.5*Dy;%0+(C{i}(j,Ny)/Cin)*Dy;%
            else
                height(j,i) = Dy*(0.5*Cin-C{i}(j,idx-1))/(C{i}(j,idx)-C{i}(j,idx-1))+(idx-1.5)*Dy;
            end
        end
        if (height(j,i)<0.51*Dy && endCurrent > j)
            endCurrent = j;
        end
        if (height(j,i)>Ly - 0.51*Dy && startCurrent < j)
            startCurrent = j;
        end
    end
        
    if (mod(i,10)==0)
        figure(1);
        hold off;
        surf(((C{i}'*1)));view(0,90);
        xlabel('x/m');ylabel('y/m');
        shading interp;
        hold on;
        plot(height(:,i)/Ly*Ny,'k','linewidth',2);
        
        axis equal;axis([0,500,0,50]);
        pause(0.01);
        figure(2);
        hold off;
        surf(((P{i}')));view(0,90);
        shading interp;%axis equal;
        hold on;
        pause(0.01);
        figure(3);
        hold off;
        UUUx = 0.5*(UUx{i}(1:Nx,:)+UUx{i}(2:Nx+1,:));
        UUUy = 0.5*(UUy{i}(:,1:Ny))+UUy{i}(:,2:Ny+1);
        quiver((UUUx'),(UUUy'));
        shading interp;%axis equal;
        hold on;
        pause(0.01);
        figure(4);
        hold off;
        if (i>1)
            hold on;
        end
        maxU = max(max(sqrt(UUUy.^2)));%UUUx.^2+
        plot(i,maxU,'ro');
        i
        
        figure (8);
        disp('vertical ratio');
        indicator = mean(mean((abs(UUUy(startCurrent-10:endCurrent+10,:)')*ratio*Visc/(9.81*Cin*(Rhos-Rhol)/Rhol*5e-3^2/12))))
        %surf(abs(UUUy')*ratio*Visc/(9.81*Cin*(Rhos-Rhol)/Rhol*5e-3^2/12));
        surf((UUUy')./(5e-3+sqrt(UUUx'.^2+UUUy'.^2)));
        shading interp;view(0,90);
        colorbar;
    end
    
    
    
end
%save('C.mat','C');
figure(5);
surf(height);shading interp;

hlaplacian = height;
hlaplacian(1:2,:) = 0; hlaplacian(Nx-1:Nx,:) = 0;
hlaplacian(3:Nx-2,:) = (height(1:Nx-4,:)*1-height(3:Nx-2,:))/Dy/2;%/Dy-height(1:Nx-2,:)

hHalf=height(:,2:2:Nt);%height;%height(:,t_end/dt/2+1:t_end/dt);%
hHalf = hHalf';%height;
%save('./post/caseI-eg3.dat','hHalf','-ascii');
save('./caseI.dat','hHalf','-ascii');

t = dt:dt:t_end;
x = Dx:Dx:Lx;
y = Dy:Dy:Ly;

[xx,tt] = meshgrid(t,x);
figure(6);

surf(xx,tt,height);shading interp;
%hold on;
%contour(height,40);
xlabel('\itt\rm/s'),ylabel('\itx\rm/m'),zlabel('\ith\rm/m');set(gca,'FontSize',12);
colorbar;

[xxx,yyy] = meshgrid(x,y);
figure(7);set(gca,'FontSize',13);
subplot(4,1,1),surf(xxx,yyy,C{1}'/Cin);
hold on;plot(x,height(:,1),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time =',num2str(0*dt),' s']);set(gca,'FontSize',12);%xlabel('\itx\rm/m'),
subplot(4,1,2),surf(xxx,yyy,C{50}'/Cin);
hold on;plot(x,height(:,50),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time =',num2str(50*dt),' s']);set(gca,'FontSize',12);%xlabel('\itx\rm/m'),
subplot(4,1,3),surf(xxx,yyy,C{200}'/Cin);
hold on;plot(x,height(:,200),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time =',num2str(200*dt),' s']);set(gca,'FontSize',12);%xlabel('\itx\rm/m'),
subplot(4,1,4),surf(xxx,yyy,C{500}'/Cin);
hold on;plot(x,height(:,500),'k','linewidth',2);
shading interp;view(0,90);
xlabel('\itx\rm/m'),ylabel('\ith\rm/m');title(['time =',num2str(500*dt),' s']);set(gca,'FontSize',12);
%end

figure(8);set(gca,'FontSize',13);
epsilon = 5e-2; 
%xxx = xxx/Ly; yyy = yyy/Ly;
i = 1*2;
UUUx = 0.5*(UUx{i}(1:Nx,:)+UUx{i}(2:Nx+1,:)); UUUy = 0.5*(UUy{i}(:,1:Ny))+UUy{i}(:,2:Ny+1);
subplot(4,1,1),surf(xxx,yyy,(UUUy')./(epsilon+sqrt(UUUx'.^2+UUUy'.^2)));
%hold on;plot(x,height(:,1),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time = ',num2str(0*dt),' s']);set(gca,'FontSize',12,'FontName','Times New Roman');%xlabel('\itx\rm/m'),
hc = colorbar;
% set(hc,'YTick',[-0.9 0 0.9]);
% set(hc,'YTickLabel',[-1 0 1]);
axis equal;axis([1,Lx,1,Ly]);
i = 50*2;
UUUx = 0.5*(UUx{i}(1:Nx,:)+UUx{i}(2:Nx+1,:)); UUUy = 0.5*(UUy{i}(:,1:Ny))+UUy{i}(:,2:Ny+1);
subplot(4,1,2),surf(xxx,yyy,(UUUy')./(epsilon+sqrt(UUUx'.^2+UUUy'.^2)));
%hold on;plot(x,height(:,50),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time = ',num2str(i*dt),' s']);set(gca,'FontSize',12,'FontName','Times New Roman');%xlabel('\itx\rm/m'),
hc = colorbar;
% set(hc,'YTick',[-0.9 0 0.9]);
% set(hc,'YTickLabel',[-1 0 1]);
axis equal;axis([1,Lx,1,Ly]);
i = 200*2;
UUUx = 0.5*(UUx{i}(1:Nx,:)+UUx{i}(2:Nx+1,:)); UUUy = 0.5*(UUy{i}(:,1:Ny))+UUy{i}(:,2:Ny+1);
subplot(4,1,3),surf(xxx,yyy,(UUUy')./(epsilon+sqrt(UUUx'.^2+UUUy'.^2)));
%subplot(4,1,3),surf(xxx,yyy,C{200}'/Cin);
%hold on;plot(x,height(:,200),'k','linewidth',2);
shading interp;view(0,90);
ylabel('\ith\rm/m');title(['time = ',num2str(i*dt),' s']);set(gca,'FontSize',12,'FontName','Times New Roman');%xlabel('\itx\rm/m'),
hc = colorbar;
% set(hc,'YTick',[-0.9 0 0.9]);
% set(hc,'YTickLabel',[-1 0 1]);
axis equal;axis([1,Lx,1,Ly]);
i = 500*2;
UUUx = 0.5*(UUx{i}(1:Nx,:)+UUx{i}(2:Nx+1,:)); UUUy = 0.5*(UUy{i}(:,1:Ny))+UUy{i}(:,2:Ny+1);
subplot(4,1,4),surf(xxx,yyy,(UUUy')./(epsilon+sqrt(UUUx'.^2+UUUy'.^2)));
%subplot(4,1,4),surf(xxx,yyy,C{500}'/Cin);
%hold on;plot(x,height(:,500),'k','linewidth',2);
shading interp;view(0,90);
xlabel('\itx\rm/m'),ylabel('\ith\rm/m');title(['time = ',num2str(i*dt),' s']);set(gca,'FontSize',12,'FontName','Times New Roman');
hc = colorbar;
% set(hc,'YTick',[-0.9 0 0.9]);
% set(hc,'YTickLabel',[-1 0 1]);
axis equal;axis([1,Lx,1,Ly]);

%end

function SetBoundary()
global Nx Ny lap Cin Ux Uy T
%idxj = 1+lap:floor(Ny/2)+lap;
T.C(1:lap,:) = Cin;
T.C(Nx+1:Nx+lap,:) = repmat(T.C(Nx,:),lap,1);%flipud(T.C(Nx-lap+1:Nx,:));
%T.C(:,1:lap) = fliplr(T.C(:,lap+1:lap+lap));
%T.C(:,Ny+lap+1:Ny+lap*2) = fliplr(T.C(:,Ny+1:Ny+lap));
T.C(:,1:lap) = repmat(T.C(:,lap+1),1,lap);
T.C(:,Ny+lap+1:Ny+lap*2) = repmat(T.C(:,Ny+lap),1,lap);

end

function RungeKutta()
global T lap Nx Ny Clim
RGcoeff = [1,0,1;3./4,1./4,1./4;1./3,2./3,2./3];
C0 = T.C(lap+1:Nx+lap,lap+1:Ny+lap);
for i=1:3
    UpdateVelocity();
    SetBoundary();
    FluxReconstruction();
    T.C(lap+1:Nx+lap,lap+1:Ny+lap) = ...
        RGcoeff(i,1)*C0+ ...
        RGcoeff(i,2)*T.C(lap+1:Nx+lap,lap+1:Ny+lap)+ ...
        RGcoeff(i,3)*FluxAccum();
    T.C = min(T.C,Clim);
end
SetBoundary();
%T.C = T.C.*(T.C>=0);
%T.C = T.C.*(T.C<Clim)+Clim.*(T.C>Clim);

end

function L = FluxAccum()
global T Nx Ny dt Dx Dy alphaf
T.Fx(2:Nx,:) = T.Fx(2:Nx,:).*(alphaf(1:Nx-1,:)+alphaf(2:Nx,:))*0.5;
T.Fy(:,2:Ny) = T.Fy(:,2:Ny).*(alphaf(:,1:Ny-1)+alphaf(:,2:Ny))*0.5;
L = (T.Fx(1:Nx,:)-T.Fx(2:Nx+1,:))*Dy+(T.Fy(:,1:Ny)-T.Fy(:,2:Ny+1))*Dx;
L = L*dt/Dx/Dy./alphaf;
end

function UpdateVelocity()
global T Ux Uy

end

function FluxReconstruction()
global Nx Ny lap
global Cin Uin Clim
global T
Fx = (T.C);
Fy = (T.C);
%Upwinding and Downwinding flux stencils & smooth intensity in x direction
be = lap+1-1:lap+Nx; bey = lap+1:Ny+lap;
STxU1 =  1./3*Fx(be-2,bey)-7./6*Fx(be-1,bey)+11./6*Fx(be-0,bey);
STxU2 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxU3 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
ISxU1 = 13./12*(Fx(be-2,bey)-2*Fx(be-1,bey)+Fx(be-0,bey)).^2+1./4*(Fx(be-2,bey)-4*Fx(be-1,bey)+3*Fx(be-0,bey)).^2;
ISxU2 = 13./12*(Fx(be-1,bey)-2*Fx(be-0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-Fx(be+1,bey)).^2;
ISxU3 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-4*Fx(be+1,bey)+3*Fx(be+2,bey)).^2;
STxD1 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxD2 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
STxD3 = 11./6*Fx(be+1,bey)-7./6*Fx(be+2,bey)+ 1./3*Fx(be+3,bey);
ISxD1 = 13./12*(Fx(be-1,bey)-2*Fx(be+0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-4*Fx(be+0,bey)+3*Fx(be+1,bey)).^2;
ISxD2 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-Fx(be+2,bey)).^2;
ISxD3 = 13./12*(Fx(be+1,bey)-2*Fx(be+2,bey)+Fx(be+3,bey)).^2+1./4*(Fx(be+1,bey)-4*Fx(be+2,bey)+3*Fx(be+3,bey)).^2;

UxUFlag = T.Ux>=0;
UxDFlag = T.Ux<0;

STx1 = STxU1.*(UxUFlag)+STxD1.*(UxDFlag);
STx2 = STxU2.*(UxUFlag)+STxD2.*(UxDFlag);
STx3 = STxU3.*(UxUFlag)+STxD3.*(UxDFlag);
ISx1 = ISxU1.*(UxUFlag)+ISxD1.*(UxDFlag);
ISx2 = ISxU2.*(UxUFlag)+ISxD2.*(UxDFlag);
ISx3 = ISxU3.*(UxUFlag)+ISxD3.*(UxDFlag);

epsilon = 1e-6; p = 2;
alpha1 = 3./10./(epsilon+ISx1).^p;
alpha2 = 3./5./(epsilon+ISx2).^p;
alpha3 = 1./10./(epsilon+ISx3).^p;
alpha = alpha1+alpha2+alpha3;
omega1 = alpha1./alpha; omega2 = alpha2./alpha; omega3 = alpha3./alpha;

T.Fx = omega1.*STx1+omega2.*STx2+omega3.*STx3;

%Upwinding and Downwinding flux stencils & smooth intensity in y direction
be = lap+1-1:lap+Ny; bex = lap+1:lap+Nx;
STyU1 =  1./3*Fy(bex,be-2)-7./6*Fy(bex,be-1)+11./6*Fy(bex,be-0);
STyU2 = -1./6*Fy(bex,be-1)+5./6*Fy(bex,be-0)+ 1./3*Fy(bex,be+1);
STyU3 =  1./3*Fy(bex,be-0)+5./6*Fy(bex,be+1)- 1./6*Fy(bex,be+2);
ISyU1 = 13./12*(Fy(bex,be-2)-2*Fy(bex,be-1)+Fy(bex,be-0)).^2+1./4*(Fy(bex,be-2)-4*Fy(bex,be-1)+3*Fy(bex,be-0)).^2;
ISyU2 = 13./12*(Fy(bex,be-1)-2*Fy(bex,be-0)+Fy(bex,be+1)).^2+1./4*(Fy(bex,be-1)-Fy(bex,be+1)).^2;
ISyU3 = 13./12*(Fy(bex,be+0)-2*Fy(bex,be+1)+Fy(bex,be+2)).^2+1./4*(Fy(bex,be+0)-4*Fy(bex,be+1)+3*Fy(bex,be+2)).^2;
STyD1 = -1./6*Fy(bex,be-1)+5./6*Fy(bex,be-0)+ 1./3*Fy(bex,be+1);
STyD2 =  1./3*Fy(bex,be-0)+5./6*Fy(bex,be+1)- 1./6*Fy(bex,be+2);
STyD3 = 11./6*Fy(bex,be+1)-7./6*Fy(bex,be+2)+ 1./3*Fy(bex,be+3);
ISyD1 = 13./12*(Fy(bex,be-1)-2*Fy(bex,be+0)+Fy(bex,be+1)).^2+1./4*(Fy(bex,be-1)-4*Fy(bex,be+0)+3*Fy(bex,be+1)).^2;
ISyD2 = 13./12*(Fy(bex,be+0)-2*Fy(bex,be+1)+Fy(bex,be+2)).^2+1./4*(Fy(bex,be+0)-Fy(bex,be+2)).^2;
ISyD3 = 13./12*(Fy(bex,be+1)-2*Fy(bex,be+2)+Fy(bex,be+3)).^2+1./4*(Fy(bex,be+1)-4*Fy(bex,be+2)+3*Fy(bex,be+3)).^2;

UyUFlag = T.Uy>=0;
UyDFlag = T.Uy<0;

STy1 = STyU1.*(UyUFlag)+STyD1.*(UyDFlag);
STy2 = STyU2.*(UyUFlag)+STyD2.*(UyDFlag);
STy3 = STyU3.*(UyUFlag)+STyD3.*(UyDFlag);
ISy1 = ISyU1.*(UyUFlag)+ISyD1.*(UyDFlag);
ISy2 = ISyU2.*(UyUFlag)+ISyD2.*(UyDFlag);
ISy3 = ISyU3.*(UyUFlag)+ISyD3.*(UyDFlag);

epsilon = 1e-6; p = 2;
alpha1 = 3./10./(epsilon+ISy1).^p;
alpha2 = 3./5./(epsilon+ISy2).^p;
alpha3 = 1./10./(epsilon+ISy3).^p;
alpha = alpha1+alpha2+alpha3;
omega1 = alpha1./alpha; omega2 = alpha2./alpha; omega3 = alpha3./alpha;

T.Fy = omega1.*STy1+omega2.*STy2+omega3.*STy3;

T.Fx = T.Fx.*T.Ux;
T.Fy = T.Fy.*T.Uy;


end



