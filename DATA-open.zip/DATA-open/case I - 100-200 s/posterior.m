clear all;
global Lx Nx Dx Ly Ny Dy lap
global Cin Clim Uin Ux Uy dt t_end
global T time Umax

close all;
%Grid
Lx = 10; Nx = 500; Dx = Lx/Nx;
Ly = 0.25; Ny = 3; Dy = Ly/Ny;
lap = 3;
%Initial
Cin = 1; Uin = 0;
Ux = 0; Uy = 0;
Clim = 1;
Umax = 0.1;
startidx=  20;
%Memory
X = (-lap+0.5)*Dx:Dx:Lx+(lap-0.5)*Dx;
Y = (-lap+0.5)*Dy:Dy:Ly+(lap-0.5)*Dy;
T.C = zeros(Nx+2*lap,Ny+2*lap);

 Hs = load('caseI.dat');
 Hs = Hs/50;%
% T.C(1:Nx/2+lap,:) = Cin;
for i=1:Ny+2*lap
    T.C(lap+1:Nx+lap,i) = Hs(startidx,:);
end


T.Fx = zeros(Nx+1,Ny);
T.Fy = zeros(Nx,Ny+1);
T.Ux = ones(Nx+1,Ny)*Ux;
T.Uy = ones(Nx,Ny+1)*Uy;

tcoeff = 1.22625e-1;%3.310149e-3  ;
%Time control
dt = 0.01*tcoeff;
t_end = 80*tcoeff;
Nt = floor((t_end+0.05*dt)/dt);
time = 0;
for i=1:Nt

    time = i*dt;
    RungeKutta();
    C(:,i) = T.C(lap+1:Nx+lap,lap+2);
    
    UpdateVelocity();

    if (mod(i,100)==0)
    figure(1);
    hold off;
    plot(C(:,i),'ro-','MarkerSize',2);
    %surf(((C{i}'*20)));view(0,90);
    %shading interp;
    hold on;
    pause(0.01);
    figure(2);
    hold off;
    plot(T.Fx(:,2),'ro-','MarkerSize',2);
    %surf(((C{i}'*20)));view(0,90);
    %shading interp;
    hold on;
    plot(4*C(:,i).^2./(4*C(:,i).^2+(1-C(:,i)).^2),'b:','MarkerSize',2);
    pause(0.01);
    end
end
figure(3);
surf(C); shading interp; view(0,90);
figure(4);
contour(C(:,5:5:t_end/dt)',20,'showtext','on');

Ntint = 20*dt;
C = C(:,Ntint/dt:Ntint/dt:t_end/dt)';
B = Hs(startidx+0:startidx+t_end/Ntint-1,:);
D = C-B;
%save('theory-I.dat','C','-ascii');

refC = load('theory-I.dat');

figure(5);
for i=1:5:length(C(:,1))
   
   plot(Dx:Dx:Lx,B(i,:),'r','linewidth',1.5);set(gca,'FontName','Times New Roman','FontSize',12);
   set(gcf,'position',[50,50,600,600]);
   axis([0,10,-0.1,1.1]);axis square;
   hold on;
   plot(Dx:Dx:Lx,C(i,:),'b','linewidth',1.5);
   plot(Dx:Dx:Lx,refC(i,:),'k','linewidth',1.5);
   hold off;
   xlabel('fracture length/m');ylabel('slurry height/m');
   legend('2D simulation','DL-PDE','theoretical PDE');%
   pause(0.1);
   str1 = ['.\output\',num2str(i),'.png'];
   f = getframe(gcf);
   imwrite(f.cdata,str1);
end

function SetBoundary()
global Nx Ny lap Cin Ux Uy T
%idxj = 1+lap:floor(Ny/2)+lap;
T.C(1:lap,:) = Cin;
T.C(Nx+1:Nx+lap,:) = repmat(T.C(Nx,:),lap,1);%flipud(T.C(Nx-lap+1:Nx,:));
%T.C(:,1:lap) = fliplr(T.C(:,lap+1:lap+lap));
%T.C(:,Ny+lap+1:Ny+lap*2) = fliplr(T.C(:,Ny+1:Ny+lap));
T.C(:,1:lap) = repmat(T.C(:,lap+1),1,lap);
T.C(:,Ny+lap+1:Ny+lap*2) = repmat(T.C(:,Ny+lap),1,lap);

end

function RungeKutta()
global T lap Nx Ny Clim Cin
RGcoeff = [1,0,1;3./4,1./4,1./4;1./3,2./3,2./3];
C0 = T.C(lap+1:Nx+lap,lap+1:Ny+lap);
for i=1:3
    UpdateVelocity();
    SetBoundary();
    FluxReconstruction();
    T.C(lap+1:Nx+lap,lap+1:Ny+lap) = ...
        RGcoeff(i,1)*C0+ ...
        RGcoeff(i,2)*T.C(lap+1:Nx+lap,lap+1:Ny+lap)+ ...
        RGcoeff(i,3)*FluxAccum();
    T.C = min(T.C,Clim);
end
T.C = T.C.*(T.C>=0);
T.C(1:4,:) = Cin;%Cin;
%T.C = T.C.*(T.C<Clim)+Clim.*(T.C>Clim);

end

function L = FluxAccum()
global T Nx Ny dt Dx Dy lap
L = (T.Fx(1:Nx,:)-T.Fx(2:Nx+1,:))*Dy+(T.Fy(:,1:Ny)-T.Fy(:,2:Ny+1))*Dx;
visc = -(T.C(lap+1:Nx+lap,lap+1:Ny+lap)*2-T.C(lap:Nx+lap-1,lap+1:Ny+lap)-T.C(lap+2:Nx+lap+1,lap+1:Ny+lap))/Dx*Dy;
%% short-term artifitial viscosity
% a = 0.89449; b = 0.0757248; c = 0.88123;
% Ugrad = (-T.C(lap:Nx+lap-1,lap+1:Ny+lap)+T.C(lap+2:Nx+lap+1,lap+1:Ny+lap))/2/Dx;
% Ctmp = T.C(lap+1:Nx+lap,lap+1:Ny+lap);
% coeff = (a-c*Ctmp).*Ctmp+(2*b).*Ugrad;
% coeff = -1*(coeff<0).*coeff;
% L = L+coeff.*visc;
% disp('max artifitial viscosity')
% max(max(coeff))
%% long-term artifitial viscosity
a = 0.87226; b = 0.88138;
Ugrad = (-T.C(lap:Nx+lap-1,lap+1:Ny+lap)+T.C(lap+2:Nx+lap+1,lap+1:Ny+lap))/2/Dx;
Ctmp = T.C(lap+1:Nx+lap,lap+1:Ny+lap);
coeff = a.*Ctmp-b.*Ctmp.*Ctmp;
coeff = -1*(coeff<0).*coeff;
L = L+coeff.*visc;
disp('max artifitial viscosity')
max(max(coeff))
L = L*dt/Dx/Dy;
end

function UpdateVelocity()
global T Ux Uy lap Nx Ny time
T.Ux(:,:) = 0;%Ux%*(sin(4*time/0.5*2*pi)); %;.*(T.C(lap:Nx+lap,lap+1:Ny+lap)+T.C(lap+1:Nx+lap+1,lap+1:Ny+lap));
T.Uy(:,:) = 0;
% T.Ux(:,:) = Ux.*(Clim-T.C)/0.1.*(T.C<Clim).*(T.C>Clim-0.1);
% T.Ux(:,:) = Ux+Ux*(T.C<CLim-0.1);
%T.Ux(:,:) = Ux.*(T.C<0.5);
%T.Uy(:,:) = Uy.*(0.5-T.C)*10.*(T.C<0.5);
%T.Uy(:,:) = Uy.*(T.C<0.5);
end

function FluxReconstruction()
global Nx Ny lap Ux Umax
global Cin Uin Clim time
global T
% Fx = (4*T.C.^2)./(4*T.C.^2+(1-T.C).^2);
% Fx = Fx.*(1+sin(4*time/0.5*2*pi));
Fx = 0.5*(CalculateFlux(T.C,time)+Umax*T.C);
Fy = (4*T.C.^2)./(4*T.C.^2+(1-T.C).^2);
%Upwinding and Downwinding flux stencils & smooth intensity in x direction
be = lap+1-1:lap+Nx; bey = lap+1:Ny+lap;
STxU1 =  1./3*Fx(be-2,bey)-7./6*Fx(be-1,bey)+11./6*Fx(be-0,bey);
STxU2 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxU3 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
ISxU1 = 13./12*(Fx(be-2,bey)-2*Fx(be-1,bey)+Fx(be-0,bey)).^2+1./4*(Fx(be-2,bey)-4*Fx(be-1,bey)+3*Fx(be-0,bey)).^2;
ISxU2 = 13./12*(Fx(be-1,bey)-2*Fx(be-0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-Fx(be+1,bey)).^2;
ISxU3 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-4*Fx(be+1,bey)+3*Fx(be+2,bey)).^2;
STxD1 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxD2 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
STxD3 = 11./6*Fx(be+1,bey)-7./6*Fx(be+2,bey)+ 1./3*Fx(be+3,bey);
ISxD1 = 13./12*(Fx(be-1,bey)-2*Fx(be+0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-4*Fx(be+0,bey)+3*Fx(be+1,bey)).^2;
ISxD2 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-Fx(be+2,bey)).^2;
ISxD3 = 13./12*(Fx(be+1,bey)-2*Fx(be+2,bey)+Fx(be+3,bey)).^2+1./4*(Fx(be+1,bey)-4*Fx(be+2,bey)+3*Fx(be+3,bey)).^2;

% UxUFlag = T.Ux>=0;
% UxDFlag = T.Ux<0;

UxUFlag = 1; UxDFlag = 0;

STx1 = STxU1.*(UxUFlag)+STxD1.*(UxDFlag);
STx2 = STxU2.*(UxUFlag)+STxD2.*(UxDFlag);
STx3 = STxU3.*(UxUFlag)+STxD3.*(UxDFlag);
ISx1 = ISxU1.*(UxUFlag)+ISxD1.*(UxDFlag);
ISx2 = ISxU2.*(UxUFlag)+ISxD2.*(UxDFlag);
ISx3 = ISxU3.*(UxUFlag)+ISxD3.*(UxDFlag);

epsilon = 1e-6; p = 4;
alpha1 = 3./10./(epsilon+ISx1).^p;
alpha2 = 3./5./(epsilon+ISx2).^p;
alpha3 = 1./10./(epsilon+ISx3).^p;
alpha = alpha1+alpha2+alpha3;
omega1 = alpha1./alpha; omega2 = alpha2./alpha; omega3 = alpha3./alpha;

T.Fx = omega1.*STx1+omega2.*STx2+omega3.*STx3;

% Fx = (4*T.C.^2)./(4*T.C.^2+(1-T.C).^2);
% Fx = Fx.*(1+sin(4*time/0.5*2*pi));
Fx = 0.5*(CalculateFlux(T.C,time)-Umax*T.C);
Fy = (4*T.C.^2)./(4*T.C.^2+(1-T.C).^2);
%Upwinding and Downwinding flux stencils & smooth intensity in x direction
be = lap+1-1:lap+Nx; bey = lap+1:Ny+lap;
STxU1 =  1./3*Fx(be-2,bey)-7./6*Fx(be-1,bey)+11./6*Fx(be-0,bey);
STxU2 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxU3 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
ISxU1 = 13./12*(Fx(be-2,bey)-2*Fx(be-1,bey)+Fx(be-0,bey)).^2+1./4*(Fx(be-2,bey)-4*Fx(be-1,bey)+3*Fx(be-0,bey)).^2;
ISxU2 = 13./12*(Fx(be-1,bey)-2*Fx(be-0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-Fx(be+1,bey)).^2;
ISxU3 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-4*Fx(be+1,bey)+3*Fx(be+2,bey)).^2;
STxD1 = -1./6*Fx(be-1,bey)+5./6*Fx(be-0,bey)+ 1./3*Fx(be+1,bey);
STxD2 =  1./3*Fx(be-0,bey)+5./6*Fx(be+1,bey)- 1./6*Fx(be+2,bey);
STxD3 = 11./6*Fx(be+1,bey)-7./6*Fx(be+2,bey)+ 1./3*Fx(be+3,bey);
ISxD1 = 13./12*(Fx(be-1,bey)-2*Fx(be+0,bey)+Fx(be+1,bey)).^2+1./4*(Fx(be-1,bey)-4*Fx(be+0,bey)+3*Fx(be+1,bey)).^2;
ISxD2 = 13./12*(Fx(be+0,bey)-2*Fx(be+1,bey)+Fx(be+2,bey)).^2+1./4*(Fx(be+0,bey)-Fx(be+2,bey)).^2;
ISxD3 = 13./12*(Fx(be+1,bey)-2*Fx(be+2,bey)+Fx(be+3,bey)).^2+1./4*(Fx(be+1,bey)-4*Fx(be+2,bey)+3*Fx(be+3,bey)).^2;

% UxUFlag = T.Ux>=0;
% UxDFlag = T.Ux<0;

UxUFlag = 0; UxDFlag = 1;

STx1 = STxU1.*(UxUFlag)+STxD1.*(UxDFlag);
STx2 = STxU2.*(UxUFlag)+STxD2.*(UxDFlag);
STx3 = STxU3.*(UxUFlag)+STxD3.*(UxDFlag);
ISx1 = ISxU1.*(UxUFlag)+ISxD1.*(UxDFlag);
ISx2 = ISxU2.*(UxUFlag)+ISxD2.*(UxDFlag);
ISx3 = ISxU3.*(UxUFlag)+ISxD3.*(UxDFlag);

epsilon = 1e-6; p = 4;
alpha1 = 3./10./(epsilon+ISx1).^p;
alpha2 = 3./5./(epsilon+ISx2).^p;
alpha3 = 1./10./(epsilon+ISx3).^p;
alpha = alpha1+alpha2+alpha3;
omega1 = alpha1./alpha; omega2 = alpha2./alpha; omega3 = alpha3./alpha;

T.Fx = T.Fx + omega1.*STx1+omega2.*STx2+omega3.*STx3;

end

function [Fx] = CalculateFlux(U,t)
global Nx Ny lap Ux Dx
global Cin Uin Clim time
global T

Ugrad = U;
nx = length(U(:,1));
Ugrad(2:nx-1,:) = (U(3:nx,:)-U(1:nx-2,:))/Dx/2;

%Fx = 1*U.*Ugrad-1*U.*U.*Ugrad;
%Fx = 0.89449*U.*Ugrad-0.881228*U.*U.*Ugrad+0.075725*Ugrad.*Ugrad;
Fx = 0.87226*U.*Ugrad-0.88138*U.*U.*Ugrad;
Fx = -Fx;

end


